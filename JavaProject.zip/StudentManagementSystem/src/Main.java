import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Student> students = FileHandler.loadStudents();
        int choice;

        do {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Update Student");
            System.out.println("3. Delete Student");
            System.out.println("4. View Students");
            System.out.println("5. Search Student");
            System.out.println("6. Save & Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Course: ");
                    String course = sc.nextLine();
                    students.add(new Student(id, name, age, course));
                }
                case 2 -> {
                    System.out.print("Enter ID to update: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    for (Student s : students) {
                        if (s.getId() == id) {
                            System.out.print("Enter New Name: ");
                            s.setName(sc.nextLine());
                            System.out.print("Enter New Age: ");
                            s.setAge(sc.nextInt());
                            sc.nextLine();
                            System.out.print("Enter New Course: ");
                            s.setCourse(sc.nextLine());
                        }
                    }
                }
                case 3 -> {
                    System.out.print("Enter ID to delete: ");
                    int id = sc.nextInt();
                    students.removeIf(s -> s.getId() == id);
                }
                case 4 -> students.forEach(System.out::println);
                case 5 -> {
                    System.out.print("Enter name to search: ");
                    String name = sc.nextLine().toLowerCase();
                    for (Student s : students) {
                        if (s.getName().toLowerCase().contains(name)) {
                            System.out.println(s);
                        }
                    }
                }
                case 6 -> {
                    FileHandler.saveStudents(students);
                    System.out.println("Data saved. Exiting...");
                }
                default -> System.out.println("Invalid choice!");
            }
        } while (choice != 6);

        sc.close();
    }
}
